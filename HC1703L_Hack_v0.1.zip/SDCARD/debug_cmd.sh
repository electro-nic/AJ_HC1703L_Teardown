#!/bin/sh

###################
# HACKS HERE
#
# The SDCARD is mounted RW in /mnt (see line 285-290 of start.sh)

# confirm hack type
touch /home/HACKSD

# run httpd on SD updated busybox
/mnt/hack/busybox httpd -p 8080 -h ./tmp/mnt/hack/www

# set new env - possibly needed but may not be
echo "comando -----------------------> mount --bind /mnt/hack/profile /etc/profile"
mount --bind /mnt/hack/profile /etc/profile

# possibly needed but may not be
echo "comando -----------------------> stessa cosa per group, passwd e shadow"
mount --bind /mnt/hack/group /etc/group
mount --bind /mnt/hack/passwd /etc/passwd
mount --bind /mnt/hack/shadow /etc/shadow

# setup and install dropbear ssh server - no password login
/mnt/hack/dropbearmulti dropbear -r /mnt/hack/dropbear_ecdsa_host_key -B

# start ftp server
(/mnt/hack/busybox tcpsvd -E 0.0.0.0 21 /mnt/hack/busybox ftpd -w / ) &
